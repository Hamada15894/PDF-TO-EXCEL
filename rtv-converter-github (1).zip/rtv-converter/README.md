# RTV Excel Converter 🚀

تحويل مرتجعات PDF إلى Excel — العثيم · التميمي · الدانوب · فارم

## 🔗 الرابط المباشر
**https://YOUR_USERNAME.github.io/rtv-converter/**

---

## ⚡ المميزات
- يدعم PDF رقمي + ممسوح ضوئياً (OCR تلقائي)
- جميع الأرقام موجبة (العثيم أرقام سالبة تُحوَّل تلقائياً)
- مطابقة المجاميع مع الـ PDF (Price Excl. VAT + Total)
- ربط تلقائي برقم المتجر → Account, Customer Code, City, Salesman
- يعمل في المتصفح — لا سيرفر، لا تثبيت

## 📊 الإخراج
**ورقة RTV Line Details:**
RTV Date | RTV/Ref# | PO Number | Internal Ref | Store# | Store Name | City | Account | Customer Code | Salesman | Item Number | Description | Qty | Unit | Unit Price | Price Excl. VAT | VAT Amount | Total incl. VAT

**ورقة Summary:**
إجماليات لكل وثيقة + Grand Total + إجماليات بالحساب

## 🏪 المتاجر المدمجة
78 متجر: Othaim, Danube, Tamimi, Farm
لإضافة متاجر: ارفع STORE_DATA.xlsx عند الاستخدام

## 🚀 نشر على GitHub Pages
```bash
git init
git add .
git commit -m "RTV Converter v6.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/rtv-converter.git
git push -u origin main
```
ثم: Settings → Pages → Source: main / root → Save

---
v6.0 | 2026
